from pathlib import Path
import subprocess, hashlib, json, datetime

out = Path(__file__).resolve().parent
oz = 'a5bd8cbd3d0bb8efbd5cf5e2edf9734f87e47640'
items = {
 'cap-0071-01.md': 'https://raw.githubusercontent.com/stellar/stellar-protocol/master/core/cap-0071-01.md',
 'cap-0071-02.md': 'https://raw.githubusercontent.com/stellar/stellar-protocol/master/core/cap-0071-02.md',
 'cap-0085.md': 'https://raw.githubusercontent.com/stellar/stellar-protocol/master/core/cap-0085.md',
 'oz-storage.rs': f'https://raw.githubusercontent.com/OpenZeppelin/stellar-contracts/{oz}/packages/accounts/src/smart_account/storage.rs',
 'oz-account.rs': f'https://raw.githubusercontent.com/OpenZeppelin/stellar-contracts/{oz}/examples/multisig-smart-account/account/src/contract.rs',
 'oz-ed25519.rs': f'https://raw.githubusercontent.com/OpenZeppelin/stellar-contracts/{oz}/examples/multisig-smart-account/ed25519-verifier/src/contract.rs',
 'oz-threshold.rs': f'https://raw.githubusercontent.com/OpenZeppelin/stellar-contracts/{oz}/packages/accounts/src/policies/simple_threshold.rs',
 'oz-weighted.rs': f'https://raw.githubusercontent.com/OpenZeppelin/stellar-contracts/{oz}/packages/accounts/src/policies/weighted_threshold.rs',
}
results = []
for name, url in items.items():
    p = subprocess.run(['curl', '-fsSL', '--max-time', '30', url], capture_output=True)
    row = {'file': name, 'url': url, 'accessed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': p.returncode}
    if p.returncode == 0:
        (out / name).write_bytes(p.stdout)
        row.update(bytes=len(p.stdout), sha256=hashlib.sha256(p.stdout).hexdigest())
    else: row['error'] = p.stderr.decode()
    results.append(row)
(out / 'primary-source-index.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
