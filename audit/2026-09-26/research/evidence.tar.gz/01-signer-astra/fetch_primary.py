import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

base = Path(__file__).resolve().parent
sources = {
    'rfc9987.txt': 'https://www.rfc-editor.org/rfc/rfc9987.txt',
    'rfc8709.txt': 'https://www.rfc-editor.org/rfc/rfc8709.txt',
    '1password-ssh.txt': 'https://developer.1password.com/llms-ssh.txt',
    'sep23.md': 'https://raw.githubusercontent.com/stellar/stellar-protocol/9cd703075d87a6ce293752b1532e7b68efe12ae1/ecosystem/sep-0023.md',
    'stellar-transaction.x': 'https://raw.githubusercontent.com/stellar/stellar-xdr/68fa1ac55692f68ad2a2ca549d0a283273554439/Stellar-transaction.x',
    'stellar-cli-signer.rs': 'https://raw.githubusercontent.com/stellar/stellar-cli/8e402ea28202950b272fbabc34caad4d2f64fe87/cmd/soroban-cli/src/signer/mod.rs',
}
rows = []
for name, url in sources.items():
    target = base / name
    command = ['curl', '-fLsS', '--max-time', '30', url, '-o', str(target)]
    result = subprocess.run(command, capture_output=True, text=True)
    row = {'name': name, 'url': url, 'command': command, 'exit': result.returncode,
           'stderr': result.stderr, 'accessed_at': datetime.now(timezone.utc).isoformat()}
    if result.returncode == 0:
        body = target.read_bytes()
        row.update(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    rows.append(row)
(base / 'primary-source-manifest.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
